package com.example.dilli.intenttest;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Dilli on 9/2/2016.
 */
public class SecondActivity extends Activity
{
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
    }
}
